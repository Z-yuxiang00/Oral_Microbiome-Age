import pandas as pd

# 读取测试集数据
test_df = pd.read_csv("Training_binary_2295.csv")

# 读取需要保留的列名（只有1列"x"）
selected_cols_df = pd.read_csv("Training_binary_2295_阈值0.5.csv")

# 提取需要保留的ASV列名列表
selected_features = selected_cols_df['x'].tolist()

# 添加 "SampleID" 和 "Age" 到保留列中
columns_to_keep = ['SampleID', 'Age', 'Sex'] + selected_features

# 仅保留同时存在于原数据中的列（避免不存在的ASV列报错）
columns_to_keep_in_data = [col for col in columns_to_keep if col in test_df.columns]

# 筛选列
filtered_df = test_df[columns_to_keep_in_data]

# 保存为新文件
filtered_df.to_csv("年龄预测_Training_binary_2295_阈值0.5.csv", index=False)
