import pandas as pd
from sklearn.model_selection import train_test_split

# 读取原始数据
df = pd.read_csv('oral_2550_age_sex_ASV_matrix.csv', dtype={'SampleID': str})

# 随机将数据按 9:1 拆分为训练集和测试集
train_data, test_data = train_test_split(df, test_size=0.1, random_state=8)

# 显示训练集和测试集
# print("Training Data:")
# print(train_data)
# print("Testing Data:")
# print(test_data)

# 将训练集和测试集分别保存为Excel文件
train_data.to_csv('Training_2295.csv', index=False)
test_data.to_csv('Testing_255.csv', index=False)
