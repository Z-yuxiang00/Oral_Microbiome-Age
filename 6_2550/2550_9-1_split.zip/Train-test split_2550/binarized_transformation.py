import pandas as pd

# 读取数据
data = pd.read_csv('Testing_255.csv', dtype={'SampleID': str})

data.set_index(data.columns[0], inplace=True)

# 对除Age列外的所有列应用转换
cols_to_transform = data.columns.difference(['Age', 'Sex'])

data[cols_to_transform] = data[cols_to_transform].applymap(lambda x: 1 if x != 0 else 0)

# 保存结果
data.to_csv('Testing_binary_255.csv', index=True)




