import pandas as pd
from matplotlib import pyplot as plt
from sklearn.metrics import mean_absolute_error, r2_score
import matplotlib.colors as mcolors
from collections import Counter
import matplotlib.ticker as ticker

# 加载数据
df1 = pd.read_excel(r"预测结果_2295-255_XGBoost.xlsx", header=0)
X1 = df1['Actual Age']
y1 = df1['Predicted Age']

df2 = pd.read_excel(r"预测结果_2295-255_XGBoost_20-59.xlsx", header=0)
X2 = df2['Actual Age']
y2 = df2['Predicted Age']

df3 = pd.read_csv(r"crossval_predictions_this study-2.csv", header=0)
X3 = df3['Actual Age']
y3 = df3['Predicted Age']

df4 = pd.read_csv(r"crossval_predictions_huang-2.csv", header=0)  # 新增
X4 = df4['Actual Age']
y4 = df4['Predicted Age']

# 计算指标
r2_1 = r2_score(X1, y1)
mae_1 = mean_absolute_error(X1, y1)

r2_2 = r2_score(X2, y2)
mae_2 = mean_absolute_error(X2, y2)

r2_3 = r2_score(X3, y3)
mae_3 = mean_absolute_error(X3, y3)

r2_4 = r2_score(X4, y4)   # 新增
mae_4 = mean_absolute_error(X4, y4)

# 统计重复点
points1 = list(zip(X1, y1))
points2 = list(zip(X2, y2))
points3 = list(zip(X3, y3))
points4 = list(zip(X4, y4))  # 新增

point_counts1 = Counter(points1)
point_counts2 = Counter(points2)
point_counts3 = Counter(points3)
point_counts4 = Counter(points4)  # 新增

# 定义颜色映射
cmap_1_5 = mcolors.LinearSegmentedColormap.from_list("cmap_1_5", ["#C1E5F5", "#64BEE6"])
cmap_6_plus = mcolors.LinearSegmentedColormap.from_list("cmap_6_plus", ["#64BEE6", "#1A759E"])

# 分离数据1-5次和6次及以上，分别为四个数据集
def split_points(points, counts):
    x_1_5 = [x for (x, y) in points if 1 <= counts[(x, y)] <= 5]
    y_1_5 = [y for (x, y) in points if 1 <= counts[(x, y)] <= 5]
    c_1_5 = [counts[(x, y)] for (x, y) in points if 1 <= counts[(x, y)] <= 5]
    x_6_plus = [x for (x, y) in points if counts[(x, y)] >= 6]
    y_6_plus = [y for (x, y) in points if counts[(x, y)] >= 6]
    c_6_plus = [counts[(x, y)] for (x, y) in points if counts[(x, y)] >= 6]
    return x_1_5, y_1_5, c_1_5, x_6_plus, y_6_plus, c_6_plus

x1_1_5, y1_1_5, colors1_1_5, x1_6_plus, y1_6_plus, colors1_6_plus = split_points(points1, point_counts1)
x2_1_5, y2_1_5, colors2_1_5, x2_6_plus, y2_6_plus, colors2_6_plus = split_points(points2, point_counts2)
x3_1_5, y3_1_5, colors3_1_5, x3_6_plus, y3_6_plus, colors3_6_plus = split_points(points3, point_counts3)
x4_1_5, y4_1_5, colors4_1_5, x4_6_plus, y4_6_plus, colors4_6_plus = split_points(points4, point_counts4)

# 获取最大值保证颜色条一致（四个数据集）
max_count = max(
    max(point_counts1.values()),
    max(point_counts2.values()),
    max(point_counts3.values()),
    max(point_counts4.values())
)

norm = mcolors.Normalize(vmin=0, vmax=max_count)

# 绘图
plt.style.use('ggplot')
plt.rcParams['axes.facecolor'] = 'white'
plt.rcParams['axes.edgecolor'] = 'black'
plt.rcParams['axes.grid'] = False
plt.rcParams['font.family'] = 'Times New Roman'

# 使用subplots和gridspec确保颜色条在右侧
# fig, axes = plt.subplots(1, 4, figsize=(24, 6), gridspec_kw={'width_ratios': [1,1,1,1]})
fig, axes = plt.subplots(2, 2, figsize=(16, 16),gridspec_kw={'width_ratios': [1,1]})

# 画第1张
ax1 = axes[0, 0]
ax1.scatter(x1_1_5, y1_1_5, c=colors1_1_5, cmap=cmap_1_5, norm=norm, alpha=1.0, s=20)
ax1.scatter(x1_6_plus, y1_6_plus, c=colors1_6_plus, cmap=cmap_6_plus, norm=norm, alpha=1.0, s=20)
ax1.plot([min(min(X1), min(y1)), max(max(X1), max(y1))], [min(min(X1), min(y1)), max(max(X1), max(y1))], linestyle='--', color='#F8750E', linewidth=1.0)
ax1.set_xlabel('Chronological Age (years)', fontsize=12)
ax1.set_ylabel('Predicted Age (years)', fontsize=12)
ax1.set_title(f"Independent validation set (n = 255)\nMAE = {mae_1:.2f} years\nR² = {r2_1:.2f}", fontsize=12)

# 画第2张
ax2 = axes[0, 1]
ax2.scatter(x2_1_5, y2_1_5, c=colors2_1_5, cmap=cmap_1_5, norm=norm, alpha=1.0, s=20)
ax2.scatter(x2_6_plus, y2_6_plus, c=colors2_6_plus, cmap=cmap_6_plus, norm=norm, alpha=1.0, s=20)
ax2.plot([min(min(X2), min(y2)), max(max(X2), max(y2))], [min(min(X2), min(y2)), max(max(X2), max(y2))], linestyle='--', color='#F8750E', linewidth=1.0)
ax2.set_xlabel('Chronological Age (years)', fontsize=12)
ax2.set_ylabel('Predicted Age (years)', fontsize=12)
ax2.set_title(f"Independent validation set (ages 20–59, n = 232)\nMAE = {mae_2:.2f} years\nR² = {r2_2:.2f}", fontsize=12)

# 画第3张
ax3 = axes[1, 0]
ax3.scatter(x3_1_5, y3_1_5, c=colors3_1_5, cmap=cmap_1_5, norm=norm, alpha=1.0, s=20)
ax3.scatter(x3_6_plus, y3_6_plus, c=colors3_6_plus, cmap=cmap_6_plus, norm=norm, alpha=1.0, s=20)
ax3.plot([min(min(X3), min(y3)), max(max(X3), max(y3))], [min(min(X3), min(y3)), max(max(X3), max(y3))], linestyle='--', color='#F8750E', linewidth=1.0)
ax3.set_xlabel('Chronological Age (years)', fontsize=12)
ax3.set_ylabel('Predicted Age (years)', fontsize=12)
ax3.set_title(f"5-fold cross-validation of the ensemble model (n = 2550)\nMAE = {mae_3:.2f} years\nR² = {r2_3:.2f}", fontsize=12)

# 画第4张（新增）
ax4 = axes[1, 1]
ax4.scatter(x4_1_5, y4_1_5, c=colors4_1_5, cmap=cmap_1_5, norm=norm, alpha=1.0, s=20)
ax4.scatter(x4_6_plus, y4_6_plus, c=colors4_6_plus, cmap=cmap_6_plus, norm=norm, alpha=1.0, s=20)
ax4.plot([min(min(X4), min(y4)), max(max(X4), max(y4))], [min(min(X4), min(y4)), max(max(X4), max(y4))], linestyle='--', color='#F8750E', linewidth=1.0)
ax4.set_xlabel('Chronological Age (years)', fontsize=12)
ax4.set_ylabel('Predicted Age (years)', fontsize=12)
ax4.set_title(f"5-fold cross-validation of Huang's model (n = 2550)\nMAE = {mae_4:.2f} years\nR² = {r2_4:.2f}", fontsize=12)

# 调整图间距，增加颜色条
# fig.subplots_adjust(right=1.1)
# cbar = fig.colorbar(ax4.collections[-1], ax=axes, fraction=0.025, pad=0.1)
fig.subplots_adjust(right=1.5)  # 留出空间
cbar_ax = fig.add_axes([1.02, 0.58, 0.02, 0.3])  # 手动添加颜色条轴 [left, bottom, width, height]
cbar = fig.colorbar(ax4.collections[-1], cax=cbar_ax)
cbar.ax.yaxis.set_major_locator(ticker.MaxNLocator(integer=True))
cbar.set_label('Sample Count', fontsize=12)

plt.tight_layout()
plt.savefig("Fig. 6.tiff", dpi=300, bbox_inches='tight')
plt.show()