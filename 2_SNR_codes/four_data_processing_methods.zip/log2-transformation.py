import pandas as pd
import numpy as np

# 读取数据
df = pd.read_csv('relative_data_150.csv', index_col=0)  # 请替换为你的文件路径，或使用read_excel如果是Excel文件

# 添加一个小常数（伪计数），避免 log(0)
pseudocount = 1e-6
df_log2 = np.log2(df + pseudocount)

# 保存结果
df_log2.to_csv('log2_data_150.csv')
