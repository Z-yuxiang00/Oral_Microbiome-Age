rm(list=ls())
graphics.off() 
setwd("pathway")
library(phyloseq)
library(ggplot2)
data <- read.csv('raw_data_150.csv', row.names = 1)
data_relative <- sweep(data, 2, colSums(data), FUN = "/")# 计算相对丰度
write.csv(data_relative,"relative_data_150.csv")