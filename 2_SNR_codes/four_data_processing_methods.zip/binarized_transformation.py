import pandas as pd

# 读取数据
data = pd.read_csv('raw_data_150.csv')

data.set_index(data.columns[0], inplace = True)

# 将非零值变为1，保持0不变
data = data.applymap(lambda x: 1 if x != 0 else 0)

data.to_csv('binarized_data_150.csv', index=True)








