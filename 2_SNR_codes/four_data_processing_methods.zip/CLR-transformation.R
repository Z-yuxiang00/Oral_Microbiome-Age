remove(list = ls())
graphics.off()
setwd("pathway")


# 1. 读取数据
asv <- read.csv("relative_data_150.csv", header = TRUE, row.names = 1, check.names = FALSE)

# 2. 转置（使每行是一个样本，列是ASV）
asv_t <- t(asv)

# 3. 加一个小伪值，避免 log(0) 错误
asv_pseudo <- asv_t + 1e-6

# 4. 定义 CLR 转换函数
clr_transform <- function(x) {
    gm <- exp(mean(log(x)))  # 几何平均数
    log(x / gm)
}

# 5. 对每个样本（行）进行 CLR 转换
asv_clr <- t(apply(asv_pseudo, 1, clr_transform))

asv_clr <- t(asv_clr)

# 6. 保存为 CSV 文件
write.csv(asv_clr, file = "CLR_data_150.csv", quote = FALSE)
