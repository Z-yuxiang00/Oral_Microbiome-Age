import pandas as pd
import numpy as np

# 1. 读取数据
file_path = 'SNR_150_log2.csv'
df_raw = pd.read_csv(file_path, index_col=0)
df = df_raw.T.copy()

# 2. 年龄分组（0-29, 30-64, 65+）
bins = [0, 30, 65, np.inf]
labels = ['0-29', '30-64', '65+']
df['age_group'] = pd.cut(df['age'], bins=bins, labels=labels, right=False)

# 3. 提取特征列（ASV）和分组标签
asv_columns = df.columns.drop(['age', 'age_group'])

# 4. 计算 SNR（单因素方差分析中的F值计算）
snr_results = {}

for col in asv_columns:
    x = df[col]
    groups = df['age_group']
    unique_groups = groups.dropna().unique()
    n_total = len(x)
    g = len(unique_groups)

    # 组内统计量初始化
    msb_num = 0.0  # 组间平方和分子部分
    msw_num = 0.0  # 组内平方和分子部分
    df_within = 0  # 组内自由度累计

    grand_mean = x.mean()

    # 计算组间与组内方差的分子部分
    for grp in unique_groups:
        x_grp = x[groups == grp]
        n_grp = len(x_grp)
        if n_grp <= 1:
            continue  # 跳过样本数<=1的组，防止方差计算错误
        mean_grp = x_grp.mean()
        var_grp = x_grp.var(ddof=1)
        msb_num += n_grp * (mean_grp - grand_mean)**2
        msw_num += (n_grp - 1) * var_grp
        df_within += n_grp - 1

    # 计算均方
    msb = msb_num / (g - 1) if g > 1 else np.nan
    msw = msw_num / df_within if df_within > 0 else np.nan

    # 计算SNR
    snr = msb / msw if (not np.isnan(msb)) and (not np.isnan(msw)) and msw != 0 else np.nan
    snr_results[col] = snr

# 5. 转为 DataFrame 排序输出
snr_df = pd.DataFrame.from_dict(snr_results, orient='index', columns=['SNR']).sort_values(by='SNR', ascending=False)

# 6. 保存为 Excel 文件
snr_df.to_excel('SNR_log2_F.xlsx')

# 查看前几项
print(snr_df.head())
