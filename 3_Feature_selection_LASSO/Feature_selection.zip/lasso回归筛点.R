graphics.off()  
rm(list = ls()) 
setwd("pathway")
library(glmnet)
library(foreign)
asv_data <- read.csv(file = "135个样_二分类变量_Training.csv", header = T, row.names = 1)
asv_data <- na.omit(asv_data)
asv_data <- t(asv_data)
age <- read.csv(file = "sample_information_Training.csv", header = T, row.names = 1)
age <-as.matrix(age[,2])
age <- as.numeric(age)

x <- asv_data
y <- age

#--------------------------------交叉验证的多次重复----------------------------------
# 初始化参数
num_repeats <- 100
selected_features <- matrix(0, nrow(x), ncol(x))
selected_features <- rep(0, ncol(x))  # 初始化特征选择计数器
# 多次重复实验
for (i in 1:num_repeats) {
    set.seed(i)  # 每次实验使用不同的随机种子
    lasso_fit <- cv.glmnet(x, y, family = "gaussian", alpha = 1, type.measure = "mse", nlambda = 100, nfolds=10) # 进行LASSO回归交叉验证
    selected <- coef(lasso_fit, s = "lambda.min")[-1] != 0  # 选择非零系数的特征
    selected_features <- selected_features + selected  # 记录被选择的特征
}

# 选择被选中频率较高的变量
threshold <- 0.5 # 设置阈值，例如被50%以上的实验选中的变量
# 计算每个特征被选择的频率
selected_frequencies <- selected_features / num_repeats
# 筛选出被稳定选择的特征
stable_features <- colnames(x)[selected_frequencies >= threshold]
# 输出稳定选择的特征
print(stable_features)
write.csv(stable_features, file = "ASV_log2_阈值0.5_Training.csv", row.names = FALSE)