import os
import random
import pandas as pd
import numpy as np
from sklearn.model_selection import KFold
from sklearn.metrics import mean_absolute_error
from sklearn.neighbors import KNeighborsRegressor  # 改为回归模型

# 固定随机种子
random.seed(8)
np.random.seed(8)

# 设置路径
# os.chdir(r"/home/smy/ZYX/调参-服务器")

# 读取数据
train_data = pd.read_excel("年龄预测_135_Training_相对丰度_阈值0.5.xlsx")
test_data = pd.read_excel("年龄预测_15_Testing_相对丰度_阈值0.5.xlsx")

# 删除非特征列
X_train_all = train_data.drop('age', axis=1)
y_train_all = train_data['age']
X_test_all = test_data.drop('age', axis=1)
y_test_all = test_data['age']

# 构建参数网格
param_grid = []
for n_neighbors in [1, 3, 5, 7, 9]:
    for weights in ['uniform', 'distance']:
        param_grid.append({
            'n_neighbors': n_neighbors,
            'weights': weights,
            'metric': 'euclidean',
            'p': None
        })
        param_grid.append({
            'n_neighbors': n_neighbors,
            'weights': weights,
            'metric': 'manhattan',
            'p': None
        })
        for p in [1, 2]:
            param_grid.append({
                'n_neighbors': n_neighbors,
                'weights': weights,
                'metric': 'minkowski',
                'p': p
            })

kf = KFold(n_splits=10, shuffle=True, random_state=8)
summary_results = []

best_mae = float('inf')
best_params = None

print("开始KNN模型调参...")

for params in param_grid:
    all_preds = []
    all_trues = []

    for train_idx, val_idx in kf.split(X_train_all):
        X_train = X_train_all.iloc[train_idx]
        y_train = y_train_all.iloc[train_idx]
        X_val = X_train_all.iloc[val_idx]
        y_val = y_train_all.iloc[val_idx]

        try:
            clf = KNeighborsRegressor(  # 修改为回归模型
                n_neighbors=params['n_neighbors'],
                weights=params['weights'],
                metric=params['metric'],
                **({'p': params['p']} if params['p'] is not None else {})
            )
            clf.fit(X_train, y_train)
            preds = clf.predict(X_val)
            all_preds.extend(preds)
            all_trues.extend(y_val)
        except Exception as e:
            print(f"跳过参数组合 {params} 时出错: {e}")
            continue

    mae = mean_absolute_error(all_trues, all_preds)
    print(f"参数 {params} -> 验证集 MAE: {mae:.4f}")

    record = {
        **params,
        'Val_MAE': mae
    }
    summary_results.append(record)

    if mae < best_mae:
        best_mae = mae
        best_params = params

print(f"\n最优参数为: {best_params}, 验证集 MAE={best_mae:.4f}")

# 用最优参数在全部训练集上训练，并在测试集上预测
final_clf = KNeighborsRegressor(  # 修改为回归模型
    n_neighbors=best_params['n_neighbors'],
    weights=best_params['weights'],
    metric=best_params['metric'],
    **({'p': best_params['p']} if best_params['p'] is not None else {})
)
final_clf.fit(X_train_all, y_train_all)
y_pred_test = final_clf.predict(X_test_all)
mae_test = mean_absolute_error(y_test_all, y_pred_test)

print(f"测试集 MAE: {mae_test:.4f}")

# 保存调参结果和测试结果
pd.DataFrame(summary_results).to_excel("调参结果_KNN_普通模型_相对丰度.xlsx", index=False)

test_result_df = pd.DataFrame({
    'Actual Age': y_test_all,
    'Predicted Age': y_pred_test
})
test_result_df.loc[len(test_result_df.index)] = ["MAE", mae_test]
test_result_df.to_excel("测试集预测结果_普通KNN模型_相对丰度.xlsx", index=False)
