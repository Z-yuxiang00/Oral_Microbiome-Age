import os
import pandas as pd
import numpy as np
from sklearn.model_selection import KFold
from sklearn.metrics import mean_absolute_error
from sklearn.neural_network import MLPRegressor
import random
import itertools

# 固定随机种子
random.seed(8)
np.random.seed(8)

# 设置路径
# os.chdir(r"/home/smy/ZYX/调参-服务器")

# 读取数据
train_data = pd.read_excel("年龄预测_135_Training_二分类_阈值0.5.xlsx")
test_data = pd.read_excel("年龄预测_15_Testing_二分类_阈值0.5.xlsx")

# 删除非特征列
X_train_all = train_data.drop('age', axis=1)
y_train_all = train_data['age']
X_test_all = test_data.drop('age', axis=1)
y_test_all = test_data['age']

# 初始神经元数量
initial_units_list = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100]

# 更细粒度搜索
def get_fine_grained_units(best_unit):
    low = max(1, best_unit - 10)
    high = min(100, best_unit + 10)
    return list(range(low, high + 1))

# 参数组合
activations = ['relu', 'tanh']
learning_rates = [0.01, 0.005, 0.001]
alphas = [1e-4, 1e-3, 1e-2]
param_combinations = list(itertools.product(activations, learning_rates, alphas))

# 评估函数（单层）
def evaluate_unit(unit, activation, learning_rate, alpha):
    all_preds = []
    all_trues = []
    kf = KFold(n_splits=10, shuffle=True, random_state=8)
    for train_idx, val_idx in kf.split(X_train_all):
        X_train = X_train_all.iloc[train_idx]
        y_train = y_train_all.iloc[train_idx]
        X_val = X_train_all.iloc[val_idx]
        y_val = y_train_all.iloc[val_idx]

        model = MLPRegressor(
            hidden_layer_sizes=(unit,),
            activation=activation,
            learning_rate_init=learning_rate,
            alpha=alpha,
            max_iter=10000,
            random_state=8
        )
        model.fit(X_train, y_train)
        preds = model.predict(X_val)
        all_preds.extend(preds)
        all_trues.extend(y_val.values)

    return mean_absolute_error(all_trues, all_preds)

# 双层结构评估函数
def evaluate_double_layer(u1, u2, activation, learning_rate, alpha):
    all_preds = []
    all_trues = []
    kf = KFold(n_splits=10, shuffle=True, random_state=8)
    for train_idx, val_idx in kf.split(X_train_all):
        X_train = X_train_all.iloc[train_idx]
        y_train = y_train_all.iloc[train_idx]
        X_val = X_train_all.iloc[val_idx]
        y_val = y_train_all.iloc[val_idx]

        model = MLPRegressor(
            hidden_layer_sizes=(u1, u2),
            activation=activation,
            learning_rate_init=learning_rate,
            alpha=alpha,
            max_iter=10000,
            random_state=8
        )
        model.fit(X_train, y_train)
        preds = model.predict(X_val)
        all_preds.extend(preds)
        all_trues.extend(y_val.values)

    return mean_absolute_error(all_trues, all_preds)

# 测试集评估
def evaluate_test_set(hidden_layers, activation, learning_rate, alpha):
    model = MLPRegressor(
        hidden_layer_sizes=hidden_layers,
        activation=activation,
        learning_rate_init=learning_rate,
        alpha=alpha,
        max_iter=10000,
        random_state=8
    )
    model.fit(X_train_all, y_train_all)
    preds = model.predict(X_test_all)
    mae = mean_absolute_error(y_test_all, preds)
    return mae, preds

# 主调参流程
results_summary = []

for activation, learning_rate, alpha in param_combinations:
    print(f"\n参数组合: activation={activation}, lr={learning_rate}, alpha={alpha}")
    unit_mae_map = {}

    # 单层网络初筛
    for unit in initial_units_list:
        mae = evaluate_unit(unit, activation, learning_rate, alpha)
        unit_mae_map[unit] = mae
        print(f"单层神经元 {unit} -> MAE={mae:.4f}")
        results_summary.append({
            'unit': unit,
            'layers': str((unit,)),
            'MAE': mae,
            'Stage': 'Initial',
            'activation': activation,
            'learning_rate': learning_rate,
            'alpha': alpha
        })

    # 精细搜索
    min_mae = min(unit_mae_map.values())
    best_initial_units = [u for u, m in unit_mae_map.items() if abs(m - min_mae) < 1e-6]

    for best_unit in best_initial_units:
        fine_units = get_fine_grained_units(best_unit)
        for unit in fine_units:
            if unit in unit_mae_map:
                continue
            mae = evaluate_unit(unit, activation, learning_rate, alpha)
            unit_mae_map[unit] = mae
            print(f"精细神经元 {unit} -> MAE={mae:.4f}")
            results_summary.append({
                'unit': unit,
                'layers': str((unit,)),
                'MAE': mae,
                'Stage': 'Fine',
                'activation': activation,
                'learning_rate': learning_rate,
                'alpha': alpha
            })

    # 双层网络调参
    for u1 in best_initial_units:
        candidate_u1 = [u1 + i for i in [-10, -5, 0, 5, 10] if 1 <= u1 + i <= 300]
        for u1_ in candidate_u1:
            u2_start = int(np.ceil(u1_ * 0.3 / 5)) * 5
            u2_end = int(np.floor(u1_ * 0.8 / 5)) * 5
            for u2 in range(u2_start, u2_end + 1, 5):
                mae = evaluate_double_layer(u1_, u2, activation, learning_rate, alpha)
                print(f"双层神经元 ({u1_}, {u2}) -> MAE={mae:.4f}")
                results_summary.append({
                    'unit': f"({u1_},{u2})",
                    'layers': str((u1_, u2)),
                    'MAE': mae,
                    'Stage': 'DoubleLayer',
                    'activation': activation,
                    'learning_rate': learning_rate,
                    'alpha': alpha
                })

# 结果处理
results_df = pd.DataFrame(results_summary)
best_row = results_df.loc[results_df['MAE'].idxmin()]
print(f"\n>>> 最优结构：{best_row['layers']}，MAE={best_row['MAE']:.4f}")

# 测试集评估
hidden_layers = eval(best_row['layers'])  # 从字符串还原成元组
test_mae, test_preds = evaluate_test_set(
    hidden_layers=hidden_layers,
    activation=best_row['activation'],
    learning_rate=best_row['learning_rate'],
    alpha=best_row['alpha']
)

print(f"\n>>> 最优模型在测试集上的 MAE: {test_mae:.4f}")

# 保存结果
results_df.to_excel("MLPRegressor_调参结果_二分类.xlsx", index=False)
pd.DataFrame([best_row]).to_excel("MLPRegressor_最优结构记录_二分类.xlsx", index=False)

prediction_df = test_data.copy()
prediction_df['Predicted_Age'] = test_preds
prediction_df.to_excel("MLPRegressor_测试集预测结果_二分类.xlsx", index=False)
