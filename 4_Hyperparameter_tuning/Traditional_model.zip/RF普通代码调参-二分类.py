import os
import pandas as pd
import numpy as np
from sklearn.model_selection import KFold, ParameterGrid
from sklearn.metrics import mean_absolute_error
from sklearn.ensemble import RandomForestRegressor
import random

random.seed(8)
np.random.seed(8)

# 设置路径
# os.chdir(r"/home/smy/ZYX/调参-服务器")

# 读取数据
train_data = pd.read_excel("年龄预测_135_Training_二分类_阈值0.5.xlsx")
test_data = pd.read_excel("年龄预测_15_Testing_二分类_阈值0.5.xlsx")

# 删除非特征列
X_train_all = train_data.drop('age', axis=1)
y_train_all = train_data['age']
X_test_all = test_data.drop('age', axis=1)
y_test_all = test_data['age']

# 参数网格
param_grid = list(ParameterGrid({
    'n_estimators': [50, 100, 200, 300, 400, 500],
    'max_depth': [5, 10, 20, None],
    'min_samples_split': [2, 5, 10],
    'min_samples_leaf': [1, 2, 4],
    'max_features': ['sqrt', 'log2'],
    'bootstrap': [True],
    'random_state': [8]
}))

kf = KFold(n_splits=10, shuffle=True, random_state=8)

# 总体结果容器
summary_results = []
best_params_overall = None
best_mae = float('inf')
best_result_record = None

print("\n开始调参...")

for params in param_grid:
    all_preds = []
    all_trues = []

    for train_idx, val_idx in kf.split(X_train_all):
        X_train = X_train_all.iloc[train_idx]
        y_train = y_train_all.iloc[train_idx]
        X_val = X_train_all.iloc[val_idx]
        y_val = y_train_all.iloc[val_idx]

        try:
            model = RandomForestRegressor(**params)
            model.fit(X_train, y_train)
            preds = model.predict(X_val)
            all_preds.extend(preds)
            all_trues.extend(y_val)
        except Exception as e:
            continue

    mae = mean_absolute_error(all_trues, all_preds)

    # 打印当前参数组合和对应的MAE
    print(f"参数组合: {params} --> 验证集 MAE = {mae:.4f}")

    result_record = {'MAE': mae}
    result_record.update(params)
    summary_results.append(result_record)

    if mae < best_mae:
        best_mae = mae
        best_params_overall = params
        best_result_record = result_record

print("\n最优参数组合:")
print(best_params_overall)
print(f"对应验证集 MAE = {best_mae:.4f}")

# === 使用最优参数，在整个训练集上重新训练 ===
final_model = RandomForestRegressor(**best_params_overall)
final_model.fit(X_train_all, y_train_all)
test_preds = final_model.predict(X_test_all)
mae_test = mean_absolute_error(y_test_all, test_preds)
print(f"\n测试集 MAE = {mae_test:.4f}")

# === 保存调参结果 ===
summary_df = pd.DataFrame(summary_results)
summary_df.to_excel("调参结果_RFR_二分类.xlsx", index=False)

# === 保存测试集预测结果 ===
test_result_df = pd.DataFrame({
    'Actual Age': y_test_all,
    'Predicted Age': test_preds
})
test_result_df.loc[len(test_result_df.index)] = ["MAE", mae_test]
test_result_df.to_excel("预测结果_Testing_最佳参数_RFR_二分类.xlsx", index=False)
