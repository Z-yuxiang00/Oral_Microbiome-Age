import os
import random
import pandas as pd
import numpy as np
from sklearn.model_selection import KFold, ParameterGrid
from sklearn.metrics import mean_absolute_error
from xgboost import XGBRegressor
import warnings
warnings.filterwarnings("ignore")

# 固定随机种子
random.seed(8)
np.random.seed(8)

# 设置路径
# os.chdir(r"/home/smy/ZYX/调参-服务器")

# 读取数据
train_data = pd.read_excel("年龄预测_135_Training_二分类_阈值0.5.xlsx")
test_data = pd.read_excel("年龄预测_15_Testing_二分类_阈值0.5.xlsx")

# 删除非特征列
X_train_all = train_data.drop('age', axis=1)
y_train_all = train_data['age']
X_test_all = test_data.drop('age', axis=1)
y_test_all = test_data['age']

# 参数网格
param_grid = list(ParameterGrid({
    'n_estimators': [100, 200],
    'max_depth': [3, 5],
    'learning_rate': [0.05, 0.1],
    'subsample': [1.0],
    'colsample_bytree': [1.0],
    'gamma': [0, 1],
    'min_child_weight': [1, 3],
    'reg_alpha': [0, 0.1],
    'reg_lambda': [1, 5]
}))

kf = KFold(n_splits=10, shuffle=True, random_state=8)

summary_results = []
best_mae = float('inf')
best_params = None

# 遍历参数组合
for params in param_grid:
    all_preds = []
    all_trues = []

    for train_idx, val_idx in kf.split(X_train_all):
        X_train = X_train_all.iloc[train_idx]
        y_train = y_train_all.iloc[train_idx]
        X_val = X_train_all.iloc[val_idx]
        y_val = y_train_all.iloc[val_idx]

        try:
            model = XGBRegressor(
                n_estimators=params['n_estimators'],
                max_depth=params['max_depth'],
                learning_rate=params['learning_rate'],
                subsample=params['subsample'],
                colsample_bytree=params['colsample_bytree'],
                gamma=params['gamma'],
                min_child_weight=params['min_child_weight'],
                reg_alpha=params['reg_alpha'],
                reg_lambda=params['reg_lambda'],
                random_state=8,
                n_jobs=-1
            )
            model.fit(X_train, y_train)
            preds = model.predict(X_val)
            all_preds.extend(preds)
            all_trues.extend(y_val)
        except Exception as e:
            print(f"跳过参数组合 {params} 时出错: {e}")
            continue

    mae = mean_absolute_error(all_trues, all_preds)
    print(f"参数 {params} -> 验证集 MAE: {mae:.4f}")

    record = {
        **params,
        'Val_MAE': mae
    }
    summary_results.append(record)

    if mae < best_mae:
        best_mae = mae
        best_params = params

print(f"\n最优参数: {best_params}, 验证集 MAE={best_mae:.4f}")

# 使用最优参数重新训练模型并预测测试集
final_model = XGBRegressor(
    **best_params,
    random_state=8,
    n_jobs=-1
)
final_model.fit(X_train_all, y_train_all)
y_pred_test = final_model.predict(X_test_all)
mae_test = mean_absolute_error(y_test_all, y_pred_test)
print(f"测试集 MAE: {mae_test:.4f}")

# 保存调参结果和测试预测
pd.DataFrame(summary_results).to_excel("XGBoost_调参结果汇总_二分类.xlsx", index=False)

test_result_df = pd.DataFrame({
    'Actual Age': y_test_all,
    'Predicted Age': y_pred_test
})
test_result_df.loc[len(test_result_df.index)] = ["MAE", mae_test]
test_result_df.to_excel("XGBoost_测试集预测结果_二分类.xlsx", index=False)
