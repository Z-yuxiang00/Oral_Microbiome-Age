import os
import pandas as pd
import numpy as np
from sklearn.model_selection import KFold, ParameterGrid
from sklearn.svm import SVR
from sklearn.metrics import mean_absolute_error
import random

random.seed(8)
np.random.seed(8)

# 设置路径
# os.chdir(r"/home/smy/ZYX/调参-服务器")

# 读取数据
train_data = pd.read_excel("年龄预测_135_Training_CLR_阈值0.5.xlsx")
test_data = pd.read_excel("年龄预测_15_Testing_CLR_阈值0.5.xlsx")

# 删除非特征列
X_train_all = train_data.drop('age', axis=1)
y_train_all = train_data['age']
X_test_all = test_data.drop('age', axis=1)
y_test_all = test_data['age']

# SVR 参数网格
param_grid = list(ParameterGrid({
    'kernel': ['linear', 'rbf', 'poly'],
    'C': [0.1, 1, 10],
    'gamma': ['scale', 'auto'],
    'epsilon': [0.5, 1.0]
}))

kf = KFold(n_splits=10, shuffle=True, random_state=8)

summary_results = []
best_mae = float('inf')
best_params = None

for params in param_grid:
    fold_maes = []

    for train_idx, val_idx in kf.split(X_train_all):
        X_train = X_train_all.iloc[train_idx]
        y_train = y_train_all.iloc[train_idx]
        X_val = X_train_all.iloc[val_idx]
        y_val = y_train_all.iloc[val_idx]

        try:
            svr = SVR(kernel=params['kernel'],
                      C=params['C'],
                      gamma=params['gamma'],
                      epsilon=params['epsilon'])
            svr.fit(X_train, y_train)
            preds = svr.predict(X_val)
            mae = mean_absolute_error(y_val, preds)
            fold_maes.append(mae)
        except Exception as e:
            print(f"跳过参数组合 {params}，出错：{e}")
            continue

    mean_mae = np.mean(fold_maes)
    print(f"参数 {params} -> 平均 MAE: {mean_mae:.4f}")

    result = params.copy()
    result['Val_MAE'] = mean_mae
    summary_results.append(result)

    if mean_mae < best_mae:
        best_mae = mean_mae
        best_params = params

print("\n✅ 最优参数:")
print(best_params)
print(f"对应验证集 MAE: {best_mae:.4f}")

# 用最优参数在全体训练集上训练，并在测试集上评估
final_model = SVR(kernel=best_params['kernel'],
                  C=best_params['C'],
                  gamma=best_params['gamma'],
                  epsilon=best_params['epsilon'])
final_model.fit(X_train_all, y_train_all)
test_preds = final_model.predict(X_test_all)
test_mae = mean_absolute_error(y_test_all, test_preds)

print(f"✅ 测试集 MAE: {test_mae:.4f}")

# 保存调参结果
pd.DataFrame(summary_results).to_excel("调参结果_SVR_CLR.xlsx", index=False)

# 保存最终预测结果
test_result_df = pd.DataFrame({
    'Actual Age': y_test_all,
    'Predicted Age': test_preds
})
test_result_df.loc[len(test_result_df.index)] = ["MAE", test_mae]
test_result_df.to_excel("预测结果_Testing_最佳参数_SVR_CLR.xlsx", index=False)

# 保存最佳参数
best_param_df = pd.DataFrame([{
    'Val_MAE': best_mae,
    'Test_MAE': test_mae,
    **best_params
}])
best_param_df.to_excel("最佳参数和测试集MAE_SVR_CLR.xlsx", index=False)
