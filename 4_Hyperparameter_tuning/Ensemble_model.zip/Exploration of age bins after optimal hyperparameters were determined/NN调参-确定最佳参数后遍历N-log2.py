import os
import pandas as pd
import numpy as np
from sklearn.model_selection import KFold
from sklearn.metrics import mean_absolute_error
from sklearn.neural_network import MLPClassifier
import random

# 固定随机种子
random.seed(8)
np.random.seed(8)

# 设置路径
# os.chdir(r"/home/smy/ZYX/调参-服务器")

# 读取数据
train_data = pd.read_excel("年龄预测_135_Training_log2_阈值0.5.xlsx")
test_data = pd.read_excel("年龄预测_15_Testing_log2_阈值0.5.xlsx")

X_train_all = train_data.drop('age', axis=1)
y_train_all = train_data['age']
X_test_all = test_data.drop('age', axis=1)
y_test_all = test_data['age']

# 分组函数
def age_groups(y, groups):
    bins = np.concatenate(([1], groups, [80]))
    return np.digitize(y, bins) - 1

# 参数固定
hidden_layers = (110, 50)
activation = 'relu'
learning_rate = 0.005
alpha = 0.01

summary_results = []
all_predictions = []

# 遍历 N（分组数量）
for N in range(1, 68):
    print(f"\n开始 N = {N} 的训练...")

    # 生成分组策略 classifiers
    classifiers = []
    for i in range(1, N + 1):
        if i == 1:
            groups = list(range(N + 1, 80, N))
        else:
            groups = list(range(i, 81, N))
        classifiers.append(groups)

    # 模型训练（训练集上进行交叉验证）
    all_preds_train = []
    all_trues_train = []
    kf = KFold(n_splits=10, shuffle=True, random_state=8)

    for repeat in range(1):
        for train_idx, val_idx in kf.split(X_train_all):
            X_train = X_train_all.iloc[train_idx]
            y_train = y_train_all.iloc[train_idx]
            X_val = X_train_all.iloc[val_idx]
            y_val = y_train_all.iloc[val_idx]

            models = []
            for groups in classifiers:
                y_train_grouped = age_groups(y_train, groups)
                clf = MLPClassifier(
                    hidden_layer_sizes=hidden_layers,
                    activation=activation,
                    learning_rate_init=learning_rate,
                    alpha=alpha,
                    max_iter=10000,
                    random_state=8
                )
                clf.fit(X_train, y_train_grouped)
                models.append((clf, groups))

            for i in range(len(X_val)):
                x_single = X_val.iloc[[i]]
                votes = np.zeros(80, dtype=int)
                for clf, groups in models:
                    pred_group = clf.predict(x_single)
                    bins = np.concatenate(([1], groups, [80]))
                    vote_range = range(bins[pred_group[0]], bins[pred_group[0] + 1])
                    for age in vote_range:
                        votes[age - 1] += 1
                final_pred = np.argmax(votes) + 1
                all_preds_train.append(final_pred)
                all_trues_train.append(y_val.values[i])

    train_mae = mean_absolute_error(all_trues_train, all_preds_train)

    # 测试集评估
    models = []
    for groups in classifiers:
        y_train_grouped = age_groups(y_train_all, groups)
        clf = MLPClassifier(
            hidden_layer_sizes=hidden_layers,
            activation=activation,
            learning_rate_init=learning_rate,
            alpha=alpha,
            max_iter=10000,
            random_state=8
        )
        clf.fit(X_train_all, y_train_grouped)
        models.append((clf, groups))

    all_preds_test = []
    for i in range(len(X_test_all)):
        x_single = X_test_all.iloc[[i]]
        votes = np.zeros(80, dtype=int)
        for clf, groups in models:
            pred_group = clf.predict(x_single)
            bins = np.concatenate(([1], groups, [80]))
            vote_range = range(bins[pred_group[0]], bins[pred_group[0] + 1])
            for age in vote_range:
                votes[age - 1] += 1
        final_pred = np.argmax(votes) + 1
        all_preds_test.append(final_pred)

    test_mae = mean_absolute_error(y_test_all, all_preds_test)

    # 保存结果
    summary_results.append({
        'N': N,
        'Train_MAE': train_mae,
        'Test_MAE': test_mae,
        'hidden_layers': hidden_layers,
        'activation': activation,
        'learning_rate': learning_rate,
        'alpha': alpha
    })

    # 保存每个测试集预测值
    for idx, pred in zip(test_data.index, all_preds_test):
        all_predictions.append({
            'N': N,
            'Sample_ID': idx,
            'True_Age': y_test_all.loc[idx],
            'Predicted_Age': pred
        })

# 保存总结果
pd.DataFrame(summary_results).to_excel("NN固定参数_遍历N_结果汇总_log2.xlsx", index=False)
pd.DataFrame(all_predictions).to_excel("NN固定参数_测试集预测结果_log2.xlsx", index=False)

print("全部完成 ✅")
