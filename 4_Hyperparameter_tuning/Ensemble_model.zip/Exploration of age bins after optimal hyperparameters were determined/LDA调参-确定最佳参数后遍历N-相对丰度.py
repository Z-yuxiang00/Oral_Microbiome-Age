import os
import random
import pandas as pd
import numpy as np
from sklearn.model_selection import KFold
from sklearn.metrics import mean_absolute_error
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis

# 固定随机种子
random.seed(8)
np.random.seed(8)

# 设置路径
# os.chdir(r"/home/smy/ZYX/调参-服务器")

# 读取数据
train_data = pd.read_excel("年龄预测_135_Training_相对丰度_阈值0.5.xlsx")
test_data = pd.read_excel("年龄预测_15_Testing_相对丰度_阈值0.5.xlsx")

X_train_all = train_data.drop('age', axis=1)
y_train_all = train_data['age']
X_test_all = test_data.drop('age', axis=1)
y_test_all = test_data['age']

# 分组函数
def age_groups(y, groups):
    bins = np.concatenate(([1], groups, [80]))
    return np.digitize(y, bins) - 1

kf = KFold(n_splits=10, shuffle=True, random_state=8)  # 固定随机种子
summary_results = []
per_N_best_params = []

# 固定参数
fixed_solver = 'svd'
fixed_shrinkage = None

for N in range(1, 65):
    print(f"\n开始遍历 N={N}...")

    # 构建分组策略
    classifiers = []
    for i in range(1, N + 1):
        if i == 1:
            groups = list(range(N + 1, 80, N))
        else:
            groups = list(range(i, 81, N))
        classifiers.append(groups)

    all_preds = []
    all_trues = []

    for repeat in range(1):
        for train_idx, val_idx in kf.split(X_train_all):
            X_train = X_train_all.iloc[train_idx]
            y_train = y_train_all.iloc[train_idx]
            X_val = X_train_all.iloc[val_idx]
            y_val = y_train_all.iloc[val_idx]

            models = []
            for groups in classifiers:
                y_train_grouped = age_groups(y_train, groups)
                try:
                    clf = LinearDiscriminantAnalysis(solver=fixed_solver, shrinkage=fixed_shrinkage)
                    clf.fit(X_train, y_train_grouped)
                    models.append((clf, groups))
                except Exception as e:
                    print(f"跳过参数组合 N={N} 时出错: {e}")
                    continue

            for i in range(len(X_val)):
                x_single = X_val.iloc[[i]]
                votes = np.zeros(80, dtype=int)

                for clf, groups in models:
                    pred_group = clf.predict(x_single)
                    bins = np.concatenate(([1], groups, [80]))
                    vote_range = range(bins[pred_group[0]], bins[pred_group[0] + 1])
                    for age in vote_range:
                        votes[age - 1] += 1

                final_pred = np.argmax(votes) + 1
                all_preds.append(final_pred)
                all_trues.append(y_val.values[i])

    mae = mean_absolute_error(all_trues, all_preds)
    print(f"N={N}, 固定参数 -> 验证集 MAE: {mae:.4f}")

    # 保存验证集结果
    summary_results.append({
        'N': N,
        'solver': fixed_solver,
        'shrinkage': fixed_shrinkage,
        'Val_MAE': mae
    })

    # 测试集预测
    best_classifiers = []
    for i in range(1, N + 1):
        if i == 1:
            groups = list(range(N + 1, 80, N))
        else:
            groups = list(range(i, 81, N))
        best_classifiers.append(groups)

    final_models = []
    for groups in best_classifiers:
        y_train_groups = age_groups(y_train_all, groups)
        clf = LinearDiscriminantAnalysis(solver=fixed_solver, shrinkage=fixed_shrinkage)
        clf.fit(X_train_all, y_train_groups)
        final_models.append((clf, groups))

    predicted_ages_test = []
    for i in range(len(X_test_all)):
        x_single = X_test_all.iloc[[i]]
        votes = np.zeros(80, dtype=int)

        for clf, groups in final_models:
            pred_group = clf.predict(x_single)
            bins = np.concatenate(([1], groups, [80]))
            vote_range = range(bins[pred_group[0]], bins[pred_group[0] + 1])
            for age in vote_range:
                votes[age - 1] += 1

        final_pred = np.argmax(votes) + 1
        predicted_ages_test.append(final_pred)

    mae_test = mean_absolute_error(y_test_all, predicted_ages_test)
    print(f"N={N} 测试集 MAE: {mae_test:.4f}")

    # 保存测试集结果
    test_result_df = pd.DataFrame({
        'Actual Age': y_test_all,
        'Predicted Age': predicted_ages_test
    })
    test_result_df.loc[len(test_result_df.index)] = ["MAE", mae_test]
    test_result_df.to_excel(f"预测结果_Testing_LDA_固定参数_N{N}-相对丰度.xlsx", index=False)

    # 保存每个N的最终结果
    per_N_best_params.append({
        'N': N,
        'solver': fixed_solver,
        'shrinkage': fixed_shrinkage,
        'Val_MAE': mae,
        'Test_MAE': mae_test
    })

# 保存汇总结果
pd.DataFrame(summary_results).to_excel("验证集结果汇总_LDA_固定参数-相对丰度.xlsx", index=False)
pd.DataFrame(per_N_best_params).to_excel("每个N的测试集MAE_LDA_固定参数-相对丰度.xlsx", index=False)
