import os
import pandas as pd
import numpy as np
from sklearn.model_selection import KFold, ParameterGrid
from sklearn.metrics import mean_absolute_error
from sklearn.ensemble import RandomForestClassifier
import random

random.seed(8)
np.random.seed(8)

# 设置路径
os.chdir(r"/home/smy/ZYX/调参-服务器")

# 读取数据
train_data = pd.read_excel("年龄预测_135_Training_CLR_阈值0.5.xlsx")
test_data = pd.read_excel("年龄预测_15_Testing_CLR_阈值0.5.xlsx")

X_train_all = train_data.drop('age', axis=1)
y_train_all = train_data['age']
X_test_all = test_data.drop('age', axis=1)
y_test_all = test_data['age']

# 分组函数
def age_groups(y, groups):
    bins = np.concatenate(([1], groups, [80]))
    return np.digitize(y, bins) - 1

# 参数网格
param_grid = list(ParameterGrid({
    'n_estimators': [50, 100, 200, 300, 400, 500],
    'max_depth': [5, 10, 20, None],
    'min_samples_split': [2, 5, 10],
    'min_samples_leaf': [1, 2, 4],
    'max_features': ['sqrt', 'log2'],
    'bootstrap': [True],
    'random_state': [8]
}))

kf = KFold(n_splits=10, shuffle=True, random_state=8)

# 总体结果容器
summary_results = []
per_N_best_params = []

# 遍历不同N
for N in range(20, 21):
    print(f"\n开始遍历 N={N}...")

    classifiers = []
    for i in range(1, N + 1):
        if i == 1:
            groups = list(range(N + 1, 80, N))
        else:
            groups = list(range(i, 81, N))
        classifiers.append(groups)

    best_mae = float('inf')
    best_params = None
    N_results = []

    for params in param_grid:
        all_preds = []
        all_trues = []

        for repeat in range(1):
            for train_idx, val_idx in kf.split(X_train_all):
                X_train = X_train_all.iloc[train_idx]
                y_train = y_train_all.iloc[train_idx]
                X_val = X_train_all.iloc[val_idx]
                y_val = y_train_all.iloc[val_idx]

                models = []
                for groups in classifiers:
                    y_train_grouped = age_groups(y_train, groups)
                    try:
                        clf = RandomForestClassifier(**params)
                        clf.fit(X_train, y_train_grouped)
                        models.append((clf, groups))
                    except Exception as e:
                        continue

                for i in range(len(X_val)):
                    x_single = X_val.iloc[[i]]
                    votes = np.zeros(80, dtype=int)

                    for clf, groups in models:
                        pred_group = clf.predict(x_single)
                        bins = np.concatenate(([1], groups, [80]))
                        vote_range = range(bins[pred_group[0]], bins[pred_group[0] + 1])
                        for age in vote_range:
                            votes[age - 1] += 1

                    final_pred = np.argmax(votes) + 1
                    all_preds.append(final_pred)
                    all_trues.append(y_val.values[i])

        mae = mean_absolute_error(all_trues, all_preds)

        # 打印当前参数组合和对应的MAE
        print(f"N={N} 参数组合: {params} --> 验证集 MAE={mae:.4f}")

        result_record = {'N': N, 'MAE': mae}
        result_record.update(params)
        summary_results.append(result_record)
        N_results.append(result_record)

        if mae < best_mae:
            best_mae = mae
            best_params = params

    print(f"N={N} 最优参数: {best_params}, 验证集MAE={best_mae:.4f}")

    # 测试集评估
    best_classifiers = []
    for i in range(1, N + 1):
        if i == 1:
            groups = list(range(N + 1, 80, N))
        else:
            groups = list(range(i, 81, N))
        best_classifiers.append(groups)

    final_models = []
    for groups in best_classifiers:
        y_train_groups = age_groups(y_train_all, groups)
        clf = RandomForestClassifier(**best_params)
        clf.fit(X_train_all, y_train_groups)
        final_models.append((clf, groups))

    predicted_ages_test = []
    for i in range(len(X_test_all)):
        x_single = X_test_all.iloc[[i]]
        votes = np.zeros(80, dtype=int)

        for clf, groups in final_models:
            pred_group = clf.predict(x_single)
            bins = np.concatenate(([1], groups, [80]))
            vote_range = range(bins[pred_group[0]], bins[pred_group[0] + 1])
            for age in vote_range:
                votes[age - 1] += 1

        final_pred = np.argmax(votes) + 1
        predicted_ages_test.append(final_pred)

    mae_test = mean_absolute_error(y_test_all, predicted_ages_test)
    print(f"N={N} 测试集 MAE: {mae_test:.4f}")

    # === 保存当前N的所有调参结果 ===
    result_df = pd.DataFrame(N_results)
    result_df.to_excel(f"调参结果_CLR_RF_N{N}.xlsx", index=False)

    # === 保存当前N的测试集预测结果 ===
    test_result_df = pd.DataFrame({
        'Actual Age': y_test_all,
        'Predicted Age': predicted_ages_test
    })
    test_result_df.loc[len(test_result_df.index)] = ["MAE", mae_test]
    test_result_df.to_excel(f"预测结果_Testing_最佳参数_CLR_RF_N{N}.xlsx", index=False)

    # 保存每个N的最优参数
    best_params_result = {'N': N, 'Val_MAE': best_mae, 'Test_MAE': mae_test}
    best_params_result.update(best_params)
    per_N_best_params.append(best_params_result)

# === 保存汇总文件 ===
summary_df = pd.DataFrame(summary_results)
summary_df.to_excel("所有调参结果汇总_CLR_RF.xlsx", index=False)

best_params_df = pd.DataFrame(per_N_best_params)
best_params_df.to_excel("每个N的最优参数和测试集MAE_CLR_RF.xlsx", index=False)
