import os
import random
import pandas as pd
import numpy as np
from sklearn.model_selection import KFold
from sklearn.metrics import mean_absolute_error
from sklearn.neighbors import KNeighborsClassifier

# 固定随机种子
random.seed(8)
np.random.seed(8)

# 设置路径
os.chdir(r"/home/smy/ZYX/调参-服务器")

# 读取数据
train_data = pd.read_excel("年龄预测_135_Training_log2_阈值0.5.xlsx")
test_data = pd.read_excel("年龄预测_15_Testing_log2_阈值0.5.xlsx")

X_train_all = train_data.drop('age', axis=1)
y_train_all = train_data['age']
X_test_all = test_data.drop('age', axis=1)
y_test_all = test_data['age']

# 年龄分组函数
def age_groups(y, groups):
    bins = np.concatenate(([1], groups, [80]))
    return np.digitize(y, bins) - 1

# 自定义参数网格（包含 p 和 metric 的合法组合）
param_grid = []

for n_neighbors in [1, 3, 5, 7, 9]:
    for weights in ['uniform', 'distance']:
        # metric='euclidean'
        param_grid.append({
            'n_neighbors': n_neighbors,
            'weights': weights,
            'metric': 'euclidean',
            'p': None  # 忽略 p
        })
        # metric='manhattan'
        param_grid.append({
            'n_neighbors': n_neighbors,
            'weights': weights,
            'metric': 'manhattan',
            'p': None  # 忽略 p
        })
        # metric='minkowski' with p=1 and p=2
        for p in [1, 2]:
            param_grid.append({
                'n_neighbors': n_neighbors,
                'weights': weights,
                'metric': 'minkowski',
                'p': p
            })

kf = KFold(n_splits=10, shuffle=True, random_state=8)
summary_results = []
per_N_best_params = []

for N in range(20, 21):
    print(f"\n开始遍历 N={N}...")

    classifiers = []
    for i in range(1, N + 1):
        if i == 1:
            groups = list(range(N + 1, 80, N))
        else:
            groups = list(range(i, 81, N))
        classifiers.append(groups)

    best_mae = float('inf')
    best_params = None
    N_results = []

    for params in param_grid:
        all_preds = []
        all_trues = []

        for repeat in range(1):
            for train_idx, val_idx in kf.split(X_train_all):
                X_train = X_train_all.iloc[train_idx]
                y_train = y_train_all.iloc[train_idx]
                X_val = X_train_all.iloc[val_idx]
                y_val = y_train_all.iloc[val_idx]

                models = []
                for groups in classifiers:
                    y_train_grouped = age_groups(y_train, groups)
                    try:
                        clf = KNeighborsClassifier(
                            n_neighbors=params['n_neighbors'],
                            weights=params['weights'],
                            metric=params['metric'],
                            **({'p': params['p']} if params['p'] is not None else {})
                        )
                        clf.fit(X_train, y_train_grouped)
                        models.append((clf, groups))
                    except Exception as e:
                        print(f"跳过参数组合 {params} 时出错: {e}")
                        continue

                for i in range(len(X_val)):
                    x_single = np.ascontiguousarray(X_val.iloc[[i]].values)
                    votes = np.zeros(80, dtype=int)

                    for clf, groups in models:
                        pred_group = clf.predict(x_single)
                        bins = np.concatenate(([1], groups, [80]))
                        vote_range = range(bins[pred_group[0]], bins[pred_group[0] + 1])
                        for age in vote_range:
                            votes[age - 1] += 1

                    final_pred = np.argmax(votes) + 1
                    all_preds.append(final_pred)
                    all_trues.append(y_val.values[i])

        mae = mean_absolute_error(all_trues, all_preds)
        print(f"N={N}, 参数 {params} -> 验证集 MAE: {mae:.4f}")

        record = {
            'N': N,
            **params,
            'Val_MAE': mae
        }
        summary_results.append(record)
        N_results.append(record)

        if mae < best_mae:
            best_mae = mae
            best_params = params

    print(f"N={N} 最优参数: {best_params}, 验证集 MAE={best_mae:.4f}")

    # 测试集预测
    best_classifiers = []
    for i in range(1, N + 1):
        if i == 1:
            groups = list(range(N + 1, 80, N))
        else:
            groups = list(range(i, 81, N))
        best_classifiers.append(groups)

    final_models = []
    for groups in best_classifiers:
        y_train_groups = age_groups(y_train_all, groups)
        clf = KNeighborsClassifier(
            n_neighbors=best_params['n_neighbors'],
            weights=best_params['weights'],
            metric=best_params['metric'],
            **({'p': best_params['p']} if best_params['p'] is not None else {})
        )
        clf.fit(X_train_all, y_train_groups)
        final_models.append((clf, groups))

    predicted_ages_test = []
    for i in range(len(X_test_all)):
        x_single = np.ascontiguousarray(X_test_all.iloc[[i]].values)
        votes = np.zeros(80, dtype=int)

        for clf, groups in final_models:
            pred_group = clf.predict(x_single)
            bins = np.concatenate(([1], groups, [80]))
            vote_range = range(bins[pred_group[0]], bins[pred_group[0] + 1])
            for age in vote_range:
                votes[age - 1] += 1

        final_pred = np.argmax(votes) + 1
        predicted_ages_test.append(final_pred)

    mae_test = mean_absolute_error(y_test_all, predicted_ages_test)
    print(f"N={N} 测试集 MAE: {mae_test:.4f}")

    # 保存调参结果和测试集预测
    pd.DataFrame(N_results).to_excel(f"调参结果_log2_KNN_N{N}.xlsx", index=False)

    test_result_df = pd.DataFrame({
        'Actual Age': y_test_all,
        'Predicted Age': predicted_ages_test
    })
    test_result_df.loc[len(test_result_df.index)] = ["MAE", mae_test]
    test_result_df.to_excel(f"预测结果_Testing_最佳参数_log2_KNN_N{N}.xlsx", index=False)

    best_params_result = {
        'N': N,
        'Val_MAE': best_mae,
        'Test_MAE': mae_test,
        **best_params
    }
    per_N_best_params.append(best_params_result)

# 保存汇总文件
pd.DataFrame(summary_results).to_excel("所有调参结果汇总_log2_KNN.xlsx", index=False)
pd.DataFrame(per_N_best_params).to_excel("每个N的最优参数和测试集MAE_log2_KNN.xlsx", index=False)
