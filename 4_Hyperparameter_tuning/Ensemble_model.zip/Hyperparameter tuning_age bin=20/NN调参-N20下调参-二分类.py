import os
import pandas as pd
import numpy as np
from sklearn.model_selection import KFold
from sklearn.metrics import mean_absolute_error
from sklearn.neural_network import MLPClassifier
import random
import itertools

# 固定随机种子
random.seed(8)
np.random.seed(8)

# 设置路径
os.chdir(r"/home/smy/ZYX/调参-服务器")

# 读取数据
train_data = pd.read_excel("年龄预测_135_Training_二分类_阈值0.5.xlsx")
test_data = pd.read_excel("年龄预测_15_Testing_二分类_阈值0.5.xlsx")

X_train_all = train_data.drop('age', axis=1)
y_train_all = train_data['age']
X_test_all = test_data.drop('age', axis=1)
y_test_all = test_data['age']

# 分组函数
def age_groups(y, groups):
    bins = np.concatenate(([1], groups, [80]))
    return np.digitize(y, bins) - 1

# 初始神经元数量
initial_units_list = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100]

# 更细粒度范围函数
def get_fine_grained_units(best_unit):
    low = max(1, best_unit - 10)
    high = min(100, best_unit + 10)
    return list(range(low, high + 1))

# 参数搜索组合
activations = ['relu', 'tanh']
learning_rates = [0.01, 0.005, 0.001]
alphas = [1e-4, 1e-3, 1e-2]
param_combinations = list(itertools.product(activations, learning_rates, alphas))

# 训练集MAE计算函数
def evaluate_unit(unit, classifiers, activation, learning_rate, alpha):
    all_preds = []
    all_trues = []
    kf = KFold(n_splits=10, shuffle=True, random_state=8)
    for repeat in range(1):
        for train_idx, val_idx in kf.split(X_train_all):
            X_train = X_train_all.iloc[train_idx]
            y_train = y_train_all.iloc[train_idx]
            X_val = X_train_all.iloc[val_idx]
            y_val = y_train_all.iloc[val_idx]

            models = []
            for groups in classifiers:
                y_train_grouped = age_groups(y_train, groups)
                clf = MLPClassifier(
                    hidden_layer_sizes=(unit,),
                    activation=activation,
                    learning_rate_init=learning_rate,
                    alpha=alpha,
                    max_iter=10000,
                    random_state=8
                )
                clf.fit(X_train, y_train_grouped)
                models.append((clf, groups))

            for i in range(len(X_val)):
                x_single = X_val.iloc[[i]]
                votes = np.zeros(80, dtype=int)
                for clf, groups in models:
                    pred_group = clf.predict(x_single)
                    bins = np.concatenate(([1], groups, [80]))
                    vote_range = range(bins[pred_group[0]], bins[pred_group[0] + 1])
                    for age in vote_range:
                        votes[age - 1] += 1
                final_pred = np.argmax(votes) + 1
                all_preds.append(final_pred)
                all_trues.append(y_val.values[i])

    mae = mean_absolute_error(all_trues, all_preds)
    return mae

# 测试集MAE评估函数，修改为返回预测结果列表
def evaluate_test_set(unit, stage, classifiers, activation, learning_rate, alpha):
    if stage == 'DoubleLayer':
        u1, u2 = eval(unit)
        hidden = (u1, u2)
    else:
        hidden = (int(unit),)

    models = []
    for groups in classifiers:
        y_train_grouped = age_groups(y_train_all, groups)
        clf = MLPClassifier(
            hidden_layer_sizes=hidden,
            activation=activation,
            learning_rate_init=learning_rate,
            alpha=alpha,
            max_iter=10000,
            random_state=8
        )
        clf.fit(X_train_all, y_train_grouped)
        models.append((clf, groups))

    all_preds = []
    for i in range(len(X_test_all)):
        x_single = X_test_all.iloc[[i]]
        votes = np.zeros(80, dtype=int)
        for clf, groups in models:
            pred_group = clf.predict(x_single)
            bins = np.concatenate(([1], groups, [80]))
            vote_range = range(bins[pred_group[0]], bins[pred_group[0] + 1])
            for age in vote_range:
                votes[age - 1] += 1
        final_pred = np.argmax(votes) + 1
        all_preds.append(final_pred)

    mae = mean_absolute_error(y_test_all, all_preds)
    return mae, all_preds

# 遍历 N（分组大小）
for N in range(20, 21):  # 可按需扩展更多N值
    print(f"\n开始 N = {N} 的训练...")

    classifiers = []
    for i in range(1, N + 1):
        if i == 1:
            groups = list(range(N + 1, 80, N))
        else:
            groups = list(range(i, 81, N))
        classifiers.append(groups)

    results_summary = []

    for activation, learning_rate, alpha in param_combinations:
        print(f"\n参数组合: activation={activation}, lr={learning_rate}, alpha={alpha}")
        unit_mae_map = {}

        for unit in initial_units_list:
            mae = evaluate_unit(unit, classifiers, activation, learning_rate, alpha)
            unit_mae_map[unit] = mae
            print(f"N={N}, Unit={unit} -> MAE={mae:.4f}")
            results_summary.append({
                'N': N,
                'unit': unit,
                'MAE': mae,
                'Stage': 'Initial',
                'activation': activation,
                'learning_rate': learning_rate,
                'alpha': alpha
            })

        min_mae = min(unit_mae_map.values())
        best_initial_units = [u for u, m in unit_mae_map.items() if abs(m - min_mae) < 1e-6]
        print(f"N={N} 初步最优神经元数: {best_initial_units}")

        best_fine_units = []
        best_fine_mae = float('inf')
        for best_unit in best_initial_units:
            fine_units = get_fine_grained_units(best_unit)
            for unit in fine_units:
                if unit in unit_mae_map:
                    continue
                mae = evaluate_unit(unit, classifiers, activation, learning_rate, alpha)
                unit_mae_map[unit] = mae
                print(f"N={N}, Fine Unit={unit} -> MAE={mae:.4f}")
                results_summary.append({
                    'N': N,
                    'unit': unit,
                    'MAE': mae,
                    'Stage': 'Fine',
                    'activation': activation,
                    'learning_rate': learning_rate,
                    'alpha': alpha
                })
                if mae < best_fine_mae:
                    best_fine_mae = mae
                    best_fine_units = [unit]
                elif abs(mae - best_fine_mae) < 1e-6:
                    best_fine_units.append(unit)

        print(f"N={N} 精细最优神经元数: {best_fine_units}")

        for first_layer_unit in best_initial_units:
            candidate_first_layer = [first_layer_unit + i for i in [-10, -5, 0, 5, 10] if
                                     1 <= first_layer_unit + i <= 300]
            for u1 in candidate_first_layer:
                u2_start = int(np.ceil(u1 * 0.3 / 5)) * 5
                u2_end = int(np.floor(u1 * 0.8 / 5)) * 5
                u2_range = list(range(u2_start, u2_end + 1, 5))
                for u2 in u2_range:
                    all_preds = []
                    all_trues = []
                    kf = KFold(n_splits=10, shuffle=True, random_state=8)
                    for repeat in range(5):
                        for train_idx, val_idx in kf.split(X_train_all):
                            X_train = X_train_all.iloc[train_idx]
                            y_train = y_train_all.iloc[train_idx]
                            X_val = X_train_all.iloc[val_idx]
                            y_val = y_train_all.iloc[val_idx]

                            models = []
                            for groups in classifiers:
                                y_train_grouped = age_groups(y_train, groups)
                                clf = MLPClassifier(
                                    hidden_layer_sizes=(u1, u2),
                                    activation=activation,
                                    learning_rate_init=learning_rate,
                                    alpha=alpha,
                                    max_iter=10000,
                                    random_state=8
                                )
                                clf.fit(X_train, y_train_grouped)
                                models.append((clf, groups))

                            for i in range(len(X_val)):
                                x_single = X_val.iloc[[i]]
                                votes = np.zeros(80, dtype=int)
                                for clf, groups in models:
                                    pred_group = clf.predict(x_single)
                                    bins = np.concatenate(([1], groups, [80]))
                                    vote_range = range(bins[pred_group[0]], bins[pred_group[0] + 1])
                                    for age in vote_range:
                                        votes[age - 1] += 1
                                final_pred = np.argmax(votes) + 1
                                all_preds.append(final_pred)
                                all_trues.append(y_val.values[i])

                    mae = mean_absolute_error(all_trues, all_preds)
                    print(f"N={N}, Hidden=({u1},{u2}) -> MAE={mae:.4f}")
                    results_summary.append({
                        'N': N,
                        'unit': f"({u1},{u2})",
                        'MAE': mae,
                        'Stage': 'DoubleLayer',
                        'activation': activation,
                        'learning_rate': learning_rate,
                        'alpha': alpha
                    })

    # 保存每个N的结果
    results_df = pd.DataFrame(results_summary)
    best_row = results_df.loc[results_df['MAE'].idxmin()]
    best_result_note = pd.DataFrame([{
        'N': N,
        'unit': best_row['unit'],
        'MAE': best_row['MAE'],
        'Stage': best_row['Stage'],
        'activation': best_row['activation'],
        'learning_rate': best_row['learning_rate'],
        'alpha': best_row['alpha']
    }])

    # 测试集 MAE 评估 + 获取预测结果
    test_mae, test_preds = evaluate_test_set(
        unit=best_row['unit'],
        stage=best_row['Stage'],
        classifiers=classifiers,
        activation=best_row['activation'],
        learning_rate=best_row['learning_rate'],
        alpha=best_row['alpha']
    )

    print(f"\n>>> N={N} 最优模型在测试集上的 MAE: {test_mae:.4f}")

    # 保存结果
    results_df.to_excel(f"NN调参结果_N{N}.xlsx", index=False)
    best_result_note.to_excel(f"NN最优结果记录_N{N}.xlsx", index=False)

    # 保存预测结果
    prediction_df = test_data.copy()
    prediction_df['Predicted_Age'] = test_preds
    prediction_df.to_excel(f"NN测试集预测结果_N{N}.xlsx", index=False)

