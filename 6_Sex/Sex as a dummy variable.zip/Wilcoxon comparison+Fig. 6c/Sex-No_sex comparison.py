import pandas as pd
from scipy.stats import ttest_rel, wilcoxon, shapiro
import matplotlib.pyplot as plt
import seaborn as sns

# 设置字体为 Times New Roman
plt.rcParams['font.family'] = 'Times New Roman'

# 读取数据
df_huang = pd.read_excel("validation_15_no_sex.xlsx")
df_this = pd.read_excel("validation_15_sex.xlsx")

# 计算绝对误差
df_huang["AE_no_sex"] = abs(df_huang["Actual Age"] - df_huang["Predicted Age"])
df_this["AE_sex"] = abs(df_this["Actual Age"] - df_this["Predicted Age"])

df = pd.DataFrame({
    "AE_no_sex": df_huang["AE_no_sex"],
    "AE_sex": df_this["AE_sex"]
})

# 正态性检验
df["diff"] = df["AE_no_sex"] - df["AE_sex"]
shapiro_stat, shapiro_p = shapiro(df["diff"])

# 检验方法选择
if shapiro_p > 0.05:
    test_method = "Paired t-test"
    t_stat, p_val = ttest_rel(df["AE_no_sex"], df["AE_sex"])
else:
    test_method = "Wilcoxon test"
    w_stat, p_val = wilcoxon(df["AE_no_sex"], df["AE_sex"])

# 转换为长格式
df_long = pd.melt(df.reset_index(), id_vars="index", value_vars=["AE_no_sex", "AE_sex"],
                  var_name="Model", value_name="AE")
df_long["Model"] = df_long["Model"].map({
    "AE_no_sex": "without sex as a dummy variable",
    "AE_sex": "with sex as a dummy variable"
})

# 绘图
plt.figure(figsize=(8, 7))
ax = sns.boxplot(x="Model", y="AE", data=df_long, palette="Set2")
sns.stripplot(x="Model", y="AE", data=df_long, color='black', size=3, alpha=0.4, jitter=True)

# 添加标题与标签（字体自动继承 Times New Roman）
plt.title("Performance comparison with or without sex as a dummy variable (n = 15)", fontsize=14)
plt.ylabel("Absolute Error (years)", fontsize=12)
plt.xlabel("")

# 添加 p 值文字注释（不加横线）
y_text = df_long["AE"].max() + 0
plt.text(0.5, y_text, f"{test_method}, p = {p_val:.4f}", ha='center', va='bottom', fontsize=11)

plt.tight_layout()
plt.savefig("Fig.6c-15.tiff", dpi=300)
plt.show()
