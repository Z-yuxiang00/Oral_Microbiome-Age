import pandas as pd

# 1. 读取主数据：含ASV和样本信息
df = pd.read_csv("oral_2516_female_binary.csv")

# 2. 读取阈值文件，提取需要保留的ASV碱基序列（注意第一列叫"x"）
keep_asvs = pd.read_csv("oral_2516_male_binary_阈值0.5.csv")["x"].tolist()

# 3. 样本信息列
meta_cols = ["SampleID", "Age"]

# 4. 找出在主表中同时存在于阈值文件中的ASV列
asv_cols_to_keep = [col for col in df.columns if col in keep_asvs]

# 5. 合并样本信息和筛选的ASV列
filtered_df = df[meta_cols + asv_cols_to_keep]

# 6. 保存结果
filtered_df.to_csv("年龄预测_2516_female_binary_filtered_by_male.csv", index=False)
