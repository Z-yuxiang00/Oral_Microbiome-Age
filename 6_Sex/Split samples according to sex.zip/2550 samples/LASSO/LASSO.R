graphics.off()  # clear all graphs
rm(list = ls()) 
setwd("D:\\Synology\\SynologyDrive\\实验室\\自己的课题\\口腔微生物+年龄\\修稿\\性别\\分男女\\2550个样本\\筛点")
library(glmnet)
library(foreign)
asv_data <- read.csv(file = "oral_2516_male_binary.csv", header = T, row.names = 1)
# asv_data <- sweep(asv_data, 2, colSums(asv_data), FUN = "/")# 计算相对丰度
# asv_data_filtered <- asv_data[rowSums(asv_data > 0) > 0.5 * ncol(asv_data), ]# 过滤低丰度的ASV
asv_data <- na.omit(asv_data)
# asv_data <- t(asv_data)
#asv_data <- asv_data[, -1] # 针对"DESeq2_normalized_data.csv"文件
# age <- read.csv(file = "周玉翔_微生物样本从头整理.csv", header = T, row.names = 1)
age <-as.matrix(asv_data[,1])
age <- as.numeric(age)

x <- as.matrix(asv_data[,-c(1,2)])
y <- age

#--------------------------------交叉验证的多次重复----------------------------------
# 初始化参数
num_repeats <- 100
selected_features <- matrix(0, nrow(x), ncol(x))
selected_features <- rep(0, ncol(x))  # 初始化特征选择计数器
# 多次重复实验
for (i in 1:num_repeats) {
    set.seed(i)  # 每次实验使用不同的随机种子
    lasso_fit <- cv.glmnet(x, y, family = "gaussian", alpha = 1, type.measure = "mse", nlambda = 100, nfolds=10) # 进行LASSO回归交叉验证
    selected <- coef(lasso_fit, s = "lambda.min")[-1] != 0  # 选择非零系数的特征
    selected_features <- selected_features + selected  # 记录被选择的特征
}

# 选择被选中频率较高的变量
threshold <- 0.5 # 设置阈值，例如被50%以上的实验选中的变量
# 计算每个特征被选择的频率
selected_frequencies <- selected_features / num_repeats
# 筛选出被稳定选择的特征
stable_features <- colnames(x)[selected_frequencies >= threshold]
# 输出稳定选择的特征
print(stable_features)
write.csv(stable_features, file = "oral_2516_male_binary_阈值0.5.csv", row.names = FALSE)
#-----------------------------------------------------------------------------------