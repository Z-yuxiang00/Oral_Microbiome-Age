import pandas as pd

# 1. 读取原始 CSV 文件
df = pd.read_csv("oral_2516_age_sex_ASV_binary.csv", dtype={'SampleID': str})

# 2. 按 Sex 列拆分为男性和女性
df_male = df[df["Sex"] == "male"]
df_female = df[df["Sex"] == "female"]

# 3. 保存为新 CSV 文件（保留所有原始列）
df_male.to_csv("oral_2516_male_binary.csv", index=False)
df_female.to_csv("oral_2516_female_binary.csv", index=False)
