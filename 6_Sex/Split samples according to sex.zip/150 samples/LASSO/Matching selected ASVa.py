import pandas as pd

# 1. 读取原始ASV矩阵（行为变量，列为样本）
df_full = pd.read_csv("female_二分类变量.csv", index_col=0)

# 2. 读取要保留的ASV编号（只保留非空且以ASV_开头的）
asv_list_df = pd.read_csv("male_二分类变量_阈值0.5.csv")
asv_list = asv_list_df['x'].dropna().tolist()

# 3. 提取要保留的行
# 一并保留 'age' 行
rows_to_keep = ['age'] + [asv for asv in asv_list if asv in df_full.index]
df_selected = df_full.loc[rows_to_keep]

# 4. 添加 SampleID 行（即列名），作为首行
df_selected_with_sampleid = df_selected.copy()
df_selected_with_sampleid.loc["SampleID"] = df_selected.columns

# 5. 重新排序行，确保 SampleID, age 在前面
row_order = ['SampleID', 'age'] + [asv for asv in asv_list if asv in df_full.index]
df_final = df_selected_with_sampleid.loc[row_order]

# 6. 保存结果
df_final.to_csv("年龄预测_female_二分类变量_male筛点.csv")
