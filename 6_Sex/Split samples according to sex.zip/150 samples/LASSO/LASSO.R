graphics.off()  # clear all graphs
rm(list = ls()) 
setwd("D:\\Synology\\SynologyDrive\\实验室\\自己的课题\\口腔微生物+年龄\\修稿\\性别\\分男女\\150个样\\筛点")
library(glmnet)
library(foreign)
asv_data <- read.csv(file = "male_二分类变量.csv", header = T, row.names = 1)
# asv_data <- sweep(asv_data, 2, colSums(asv_data), FUN = "/")# 计算相对丰度
# asv_data_filtered <- asv_data[rowSums(asv_data > 0) > 0.5 * ncol(asv_data), ]# 过滤低丰度的ASV
asv_data <- na.omit(asv_data)
asv_data <- t(asv_data)
asv_filtered <- asv_data[, -c(1, 2)]
#asv_data <- asv_data[, -1] # 针对"DESeq2_normalized_data.csv"文件
# age <- read.csv(file = "周玉翔_微生物样本从头整理_Training_5.csv", header = T, row.names = 1)
age <-as.matrix(asv_data[,2])
age <- as.numeric(age)

x <- asv_filtered
y <- age

#--------------------------------交叉验证的多次重复----------------------------------
# 初始化参数
num_repeats <- 100
selected_features <- matrix(0, nrow(x), ncol(x))
selected_features <- rep(0, ncol(x))  # 初始化特征选择计数器
# 多次重复实验
for (i in 1:num_repeats) {
    set.seed(i)  # 每次实验使用不同的随机种子
    lasso_fit <- cv.glmnet(x, y, family = "gaussian", alpha = 1, type.measure = "mse", nlambda = 100, nfolds=10) # 进行LASSO回归交叉验证
    selected <- coef(lasso_fit, s = "lambda.min")[-1] != 0  # 选择非零系数的特征
    selected_features <- selected_features + selected  # 记录被选择的特征
}

# 选择被选中频率较高的变量
threshold <- 0.5 # 设置阈值，例如被50%以上的实验选中的变量
# 计算每个特征被选择的频率
selected_frequencies <- selected_features / num_repeats
# 筛选出被稳定选择的特征
stable_features <- colnames(x)[selected_frequencies >= threshold]
# 输出稳定选择的特征
print(stable_features)
write.csv(stable_features, file = "male_二分类变量_阈值0.5.csv", row.names = FALSE)
#-----------------------------------------------------------------------------------

set.seed(50)  # 设置随机种子以确保结果一致性

fit <- glmnet(x, y, family="gaussian", nlambda=100, alpha=1, nfolds = 5) #这里alpha=1为LASSO回归，如果等于0就是岭回归
#参数 family 规定了回归模型的类型：
#family="gaussian" 适用于一维连续因变量（univariate）
#family="mgaussian" 适用于多维连续因变量（multivariate）
#family="poisson" 适用于非负次数因变量（count）
#family="binomial" 适用于二元离散因变量（binary）
#family="multinomial" 适用于多元离散因变量（category）
#我们这里结局指标是2分类变量，所以使用binomial

print(fit)
plot(fit, xvar="lambda")

lasso_fit<-cv.glmnet(x,y,family="gaussian",alpha = 1, type.measure = "mse", nlambda=200, nfolds = 10)
plot(lasso_fit)
print(lasso_fit)


lasso_best <-glmnet(x=x, y=y, alpha = 1,lambda = lasso_fit$lambda.min)
coef(lasso_best)

coefficient <-coef(lasso_best, s=lasso_best$lambda.min)
coe <- coefficient@x
coe <- as.data.frame(coe)
Active_Index <- which(as.numeric(coefficient)!=0)
active_coefficients <- as.numeric(coefficient)[Active_Index]
variable <-rownames(coefficient)[Active_Index]
variable <- as.data.frame(variable)
variable <-cbind(variable,coe)
View(variable)
write.csv(variable, file = "随机种子为50得到的genus_lasso结果.csv", row.names = FALSE)

#------------------进行预测-------------------------------
new = matrix(rnorm(40923), nrow=1, ncol=40923)
predict(lasso_best, s=lasso_best$lambda.min, newx = new )
