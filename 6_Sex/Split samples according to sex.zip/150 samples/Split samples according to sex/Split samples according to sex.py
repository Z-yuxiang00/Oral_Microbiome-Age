import pandas as pd

# === 1. 读取原始CSV文件 ===
df = pd.read_csv("150个样_未抽平数据_二分类变量+性别.csv", index_col=0)

# === 2. 提取性别信息 ===
gender_row = df.loc["gender"]  # Series: 样本名 -> 性别

# === 3. 获取男性和女性的样本名（列名）===
male_cols = gender_row[gender_row == "male"].index
female_cols = gender_row[gender_row == "female"].index

# === 4. 拆分原始表格（保留所有行）===
male_df = df[male_cols]
female_df = df[female_cols]

# === 5. 保存为新文件 ===
male_df.to_csv("male_二分类变量.csv")
female_df.to_csv("female_二分类变量.csv")
